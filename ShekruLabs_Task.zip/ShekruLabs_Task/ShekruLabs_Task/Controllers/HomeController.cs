﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using ShekruLabs_Task.Models;
using System.Net.Mail;

namespace ShekruLabs_Task.Controllers
{
    public class HomeController : Controller
    {
        private readonly MVC_ShekruContext _context;

        public HomeController(MVC_ShekruContext context)
        {
            _context = context;
        }

        public IActionResult AddEmployee()
        {
            ViewBag.DesignationList = new SelectList(_context.Designations, "Id", "DesignationName");
           
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddEmployee(Employee employee)
        {
            var emp = new Employee
            {
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                EmailAddress = employee.EmailAddress,
                PhoneNumber = employee.PhoneNumber,
                DesignationIdRef = employee.DesignationIdRef,
                GradeIdRef = employee.GradeIdRef,
            };

            await _context.Employees.AddAsync(emp);
            await _context.SaveChangesAsync();
            return RedirectToAction("ListEmployee", "Home");
        }

        [HttpGet]
        public async Task<IActionResult> ListEmployee()
        {
            var employee = await _context.Employees.ToListAsync();

            return View(employee);
        }

        [HttpGet]
        public async Task<IActionResult> EditEmployee(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            ViewBag.DesignationList = new SelectList(_context.Designations, "Id", "DesignationName");
            ViewBag.GradeList = new SelectList(_context.DesignationGrades, "Id", "GradeName");
            return View(employee);
        }

        [HttpPost]
        public async Task<IActionResult> EditEmployee(Employee employee)
        {
            var emp = await _context.Employees.FindAsync(employee.Id);

            if (emp != null)
            {
                emp.FirstName = employee.FirstName;
                emp.LastName = employee.LastName;
                emp.EmailAddress = employee.EmailAddress;
                emp.PhoneNumber = employee.PhoneNumber;
                emp.DesignationIdRef = employee.DesignationIdRef;
                emp.GradeIdRef = employee.GradeIdRef;

                await _context.SaveChangesAsync();
            }

            return RedirectToAction("ListEmployee", "Home");
        }

        [HttpPost]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee != null)
            {
                _context.Employees.Remove(employee);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("ListEmployee", "Home");
        }



        [HttpGet]
        public JsonResult GetGradesByDesignation(int designationId)
        {
            var grades = _context.DesignationGrades
                                 .Where(g => g.DesignationIdref == designationId && g.IsActive)
                                 .Select(g => new { g.Id, g.GradeName })
                                 .ToList();

            return Json(grades);
        }

    
    }
}
